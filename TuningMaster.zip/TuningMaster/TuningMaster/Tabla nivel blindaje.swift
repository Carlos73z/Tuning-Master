//


import UIKit

struct Blindaje{
    var portada:UIImage
    var uso:String
    var modelo:String
    var marca:String
}

var arregloNivelBlindaje:[
    Blindaje]=[Blindaje(portada: UIImage(named: "Blindaje2")!, uso: "Transporte", modelo: "2021", marca: "chevrolet"), Blindaje(portada: UIImage(named: "Blindaje3")!, uso: "Comercio", modelo: "2019", marca: "Ford"),Blindaje(portada: UIImage(named: "Blindaje4")!, uso: "Vigilancia", modelo: "2020", marca: "GMC"), Blindaje(portada: UIImage(named: "Blindaje5")!, uso: "Policìa", modelo: "2016", marca: "RAM")
        ]


class Tabla_nivel_blindaje: UIViewController, UITableViewDelegate, UITableViewDataSource {
   

    @IBOutlet weak var tbNivelBlindaje: UITableView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tbNivelBlindaje.dataSource=self
        tbNivelBlindaje.delegate=self

        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arregloNivelBlindaje.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tbNivelBlindaje.dequeueReusableCell(withIdentifier:"celda1", for: indexPath) as! CeldaBlindaje
        let celdaReusada = arregloNivelBlindaje[indexPath.row]
        
        celda.imgblindaje2.image=celdaReusada.portada
        celda.lblMarca.text=celdaReusada.marca
        celda.lblModelo.text=celdaReusada.modelo
        celda.lblUso.text=celdaReusada.uso
        
        return celda
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
     return 150
    }
    
    override func viewDidAppear(_ animated: Bool) {
        tbNivelBlindaje.reloadData()
    }
    

    

}
