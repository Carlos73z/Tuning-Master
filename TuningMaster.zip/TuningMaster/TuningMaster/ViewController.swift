//
//  ViewController.swift
//  TuningMaster
//
//  Created by UNAM-Apple18 on 11/01/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func regeresarInicio(_sender:UIStoryboardSegue){
      }


  }
