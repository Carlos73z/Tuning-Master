//
//  CeldaBlindaje.swift
//  TuningMaster
//
//  Created by UNAM-Apple18 on 19/01/23.
//

import UIKit

class CeldaBlindaje: UITableViewCell {

    @IBOutlet weak var llblllenar3: UITextField!
    @IBOutlet weak var lblllenar2: UITextField!
    @IBOutlet weak var lblllenar11: UITextField!
   
    @IBOutlet weak var lblUso: UILabel!
    @IBOutlet weak var lblModelo: UILabel!
    @IBOutlet weak var lblMarca: UILabel!
    @IBOutlet weak var imgblindaje2: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
